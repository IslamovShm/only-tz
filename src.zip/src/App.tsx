import TimelineBlock from "./components/timeline-block"


const App = () => {

  return (
    <>
      <TimelineBlock />
    </>
  )
}

export default App