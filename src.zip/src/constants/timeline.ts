export const CIRCLE = {
  CX: 265,
  CY: 265,
  R: 264,
  SIZE: 530,
} as const;

export const ANCHOR_ID = 6;

export const MOBILE_BREAKPOINT = "(max-width: 768px)";